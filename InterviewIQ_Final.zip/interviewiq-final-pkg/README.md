# InterviewIQ

A resume-aware, adaptive mock interview platform. A candidate uploads their resume (PDF),
picks an interview type and difficulty, and answers a 6-question interview where each
question is grounded in their actual projects/skills — follow-up questions probe deeper on
weak answers, and the final report scores technical depth, project understanding, and
communication with personalized recommendations.

## Features

- **Resume upload & parsing** — PDF upload, text extraction, structured profile extraction
  (skills, projects, experience) via an LLM.
- **Adaptive interview orchestration** — 6 questions per interview, grounded in the resume,
  with a `FOLLOW_UP` vs `NEW_TOPIC` decision after every answer based on answer depth.
- **Final evaluation report** — weighted composite scoring (not a raw average) across 5
  categories, per-project understanding assessment, question-by-question analysis, and
  personalized recommendations tied to actual gaps detected in the interview.
- **Final Evaluation Dashboard** (React) — displays the report and offers a "Practice Again"
  CTA that starts a new interview against the same resume.
- **Runs without any API keys or a real database** — falls back to an in-process mock LLM
  provider and an in-memory data store for local development/testing, and switches to real
  MongoDB/OpenAI automatically once you provide credentials.

## Architecture

```
React (Vite) frontend  ──HTTP──►  Express backend  ──►  MongoDB (or in-memory fallback)
                                        │
                                        └──►  OpenAI (or mock provider fallback)
```

**Backend** (`backend/`) — Express + Mongoose, organized by responsibility:
- `routes/` + `controllers/` — HTTP layer
- `services/` — business logic (`resumeParser`, `interviewOrchestrator`, `interviewGenerator`,
  `answerEvaluator`, `scoreEngine`, `reportGenerator`)
- `llm/` — provider abstraction (`openaiProvider` for real calls, `mockProvider` as a
  resume-aware dev/test double, selected automatically based on whether `OPENAI_API_KEY` is set)
- `db/` — repository pattern over Mongoose models, with an in-memory fallback store used
  automatically when `MONGODB_URI` is not set

**Frontend** (`frontend/`) — React + Vite, single dashboard app that fetches a finished
interview's report and renders it.

## Prerequisites

- **Node.js 18+** (uses native `node --test` and ES modules)
- **npm 9+**
- **Python 3** (only needed to run the backend's integration test script)
- MongoDB and an OpenAI API key are **optional** — see [Environment variables](#environment-variables).

## Installation

From the project root (`interviewiq/`):

```bash
npm run install:all
```

This installs dependencies for both `backend/` and `frontend/`. (You can also `cd` into each
folder and run `npm install` separately.)

## Environment variables

Copy the example files and fill in real values only if you want to use live services:

```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

**`backend/.env`**

| Variable | Required? | Default behavior if unset |
|---|---|---|
| `PORT` | No | `4000` |
| `MONGODB_URI` | No | Falls back to an in-process in-memory store (data resets on restart) |
| `OPENAI_API_KEY` | No | Falls back to a heuristic mock LLM provider (no real AI calls) |
| `OPENAI_MODEL` | No | `gpt-4o-mini` |

**`frontend/.env`**

| Variable | Required? | Default behavior if unset |
|---|---|---|
| `VITE_API_BASE_URL` | No | `http://localhost:4000/api` |

The app is fully runnable with **no `.env` files at all** — it just runs in mock/in-memory
mode. Add real `MONGODB_URI` / `OPENAI_API_KEY` values whenever you want live persistence and
real AI-generated questions/evaluations.

## Running locally

### Option A — one command from the root

```bash
npm run dev
```

Starts both backend (`:4000`) and frontend (`:5173`) concurrently in one terminal, with
color-coded `[backend]` / `[frontend]` log prefixes.

### Option B — two separate terminals

**Terminal 1 — backend:**
```bash
npm run backend
```

**Terminal 2 — frontend:**
```bash
npm run frontend
```

Once both are running, open **http://localhost:5173** in your browser.

## Running tests

**Backend unit tests** (mock resume parser + score engine — no server needed):
```bash
npm test
```

**Backend integration tests** (exercises the full HTTP API — requires the backend to be
running separately first):
```bash
# Terminal 1
npm run backend

# Terminal 2
npm run test:integration
```

## Project layout

```
interviewiq/
├── package.json              # root convenience scripts (this file's sibling)
├── README.md                 # you are here
├── backend/
│   ├── package.json
│   ├── .env.example
│   ├── src/
│   │   ├── server.js
│   │   ├── config/
│   │   ├── constants/
│   │   ├── controllers/
│   │   ├── routes/
│   │   ├── services/
│   │   ├── llm/
│   │   ├── db/
│   │   ├── models/
│   │   └── middleware/
│   ├── tests/                 # unit tests (node --test)
│   └── test_interview_flow.py # integration test (needs a running server)
└── frontend/
    ├── package.json
    ├── .env.example
    ├── index.html
    └── src/
        ├── App.jsx
        ├── api/
        └── components/
```
