# InterviewIQ — Frontend

React + Vite app for the Final Evaluation Dashboard.

See the [project root README](../README.md) for setup, environment variables, and how to run
this alongside the backend.

Quick start (from this folder):
```bash
npm install
npm run dev
```
Runs on http://localhost:5173 by default.
