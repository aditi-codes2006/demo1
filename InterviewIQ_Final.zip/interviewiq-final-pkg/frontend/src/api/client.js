const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000/api';

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: options.body instanceof FormData ? undefined : { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `Request failed (${res.status})`);
    err.statusCode = res.status;
    throw err;
  }
  return data;
}

export const api = {
  uploadResume: (file) => {
    const formData = new FormData();
    formData.append('resume', file);
    return request('/resume/upload', { method: 'POST', body: formData });
  },
  getResume: (resumeId) => request(`/resume/${resumeId}`),

  getInterview: (id) => request(`/interview/${id}`),
  startInterview: (resumeId, interviewType, difficulty) =>
    request('/interview/start', {
      method: 'POST',
      body: JSON.stringify({ resumeId, interviewType, difficulty }),
    }),
  submitAnswer: (interviewId, answer) =>
    request('/interview/answer', {
      method: 'POST',
      body: JSON.stringify({ interviewId, answer }),
    }),
  finishInterview: (interviewId) =>
    request('/interview/finish', { method: 'POST', body: JSON.stringify({ interviewId }) }),
};
