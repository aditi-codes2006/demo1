import { useNavigate, Link } from 'react-router-dom';
import './pages.css';

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="page">
      <div className="page__eyebrow">$ interviewiq</div>
      <h1 className="page__title">Practice interviews grounded in your actual resume.</h1>
      <p className="page__subtitle">
        Upload your resume, pick an interview type and difficulty, and answer 6 adaptive
        questions built from your real projects and skills — with follow-ups when an answer
        needs more depth, and a detailed evaluation report at the end.
      </p>

      <div className="page__panel">
        <button className="btn" onClick={() => navigate('/upload')}>Get Started</button>
      </div>

      <Link className="debug-link" to="/lookup">Have an interview ID already? Look up a report →</Link>
    </div>
  );
}
