import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/client.js';
import './pages.css';

export default function InterviewRoomPage() {
  const { interviewId } = useParams();
  const navigate = useNavigate();

  const [question, setQuestion] = useState(null);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [answer, setAnswer] = useState('');
  const [lastEvaluation, setLastEvaluation] = useState(null);
  const [status, setStatus] = useState('loading'); // loading | ready | submitting | error
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const iv = await api.getInterview(interviewId);
        if (cancelled) return;
        if (iv.status === 'completed') {
          navigate(`/report/${interviewId}`, { replace: true });
          return;
        }
        setQuestion(iv.currentQuestion);
        setQuestionNumber(iv.questionNumber);
        setStatus('ready');
      } catch (err) {
        if (!cancelled) {
          setError(err.message);
          setStatus('error');
        }
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interviewId]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!answer.trim() || status === 'submitting') return;
    setStatus('submitting');
    setError('');
    try {
      const result = await api.submitAnswer(interviewId, answer);
      if (result.status === 'completed') {
        navigate(`/report/${interviewId}`);
        return;
      }
      setLastEvaluation(result.evaluation);
      setQuestion(result.nextQuestion);
      setQuestionNumber(result.questionNumber);
      setAnswer('');
      setStatus('ready');
    } catch (err) {
      setError(err.message);
      setStatus('error');
    }
  }

  if (status === 'loading') {
    return <div className="page"><p className="status-text">Loading interview…</p></div>;
  }

  if (status === 'error' && !question) {
    return <div className="page"><p className="status-text status-text--error">{error}</p></div>;
  }

  return (
    <div className="page">
      <div className="page__eyebrow">Step 4 of 4 — Interview Room</div>
      <h1 className="page__title">Question {questionNumber} of 6</h1>

      {lastEvaluation && (
        <div className="eval-note">
          <strong>Previous answer:</strong> {lastEvaluation.feedback}
        </div>
      )}

      {question && (
        <div className="question-card">
          <div className="question-card__topic">{question.topic}</div>
          <div className="question-card__text">{question.text}</div>
        </div>
      )}

      <form className="page__panel" onSubmit={handleSubmit}>
        <div className="field">
          <label className="field__label" htmlFor="answer">Your Answer</label>
          <textarea
            id="answer"
            className="field__textarea"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            placeholder="Type your answer here…"
          />
        </div>
        <button className="btn" type="submit" disabled={!answer.trim() || status === 'submitting'}>
          {status === 'submitting' ? 'Submitting…' : 'Submit Answer'}
        </button>
        {status === 'error' && <p className="status-text status-text--error">{error}</p>}
      </form>
    </div>
  );
}
