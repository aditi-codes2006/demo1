import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './pages.css';

export default function DebugLookupPage() {
  const navigate = useNavigate();
  const [interviewId, setInterviewId] = useState('');

  function handleLoad() {
    const id = interviewId.trim();
    if (!id) return;
    navigate(`/report/${id}`);
  }

  return (
    <div className="page">
      <div className="page__eyebrow">Debug / Fallback</div>
      <h1 className="page__title">Look up a report by interview ID</h1>
      <p className="page__subtitle">For debugging — normally you'd reach the report automatically after completing an interview.</p>

      <div className="page__panel">
        <div className="field">
          <label className="field__label" htmlFor="interview-id">Interview ID</label>
          <input
            id="interview-id"
            className="field__select"
            placeholder="Paste an interview ID…"
            value={interviewId}
            onChange={(e) => setInterviewId(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleLoad()}
          />
        </div>
        <button className="btn" onClick={handleLoad} disabled={!interviewId.trim()}>Load Report</button>
      </div>
    </div>
  );
}
