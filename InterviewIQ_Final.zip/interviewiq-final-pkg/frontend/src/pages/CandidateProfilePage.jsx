import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/client.js';
import './pages.css';

export default function CandidateProfilePage() {
  const { resumeId } = useParams();
  const navigate = useNavigate();
  const [resume, setResume] = useState(null);
  const [status, setStatus] = useState('loading'); // loading | ready | error
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await api.getResume(resumeId);
        if (!cancelled) {
          setResume(data);
          setStatus('ready');
        }
      } catch (err) {
        if (!cancelled) {
          setError(err.message);
          setStatus('error');
        }
      }
    })();
    return () => { cancelled = true; };
  }, [resumeId]);

  if (status === 'loading') {
    return (
      <div className="page">
        <p className="status-text">Loading profile…</p>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="page">
        <p className="status-text status-text--error">{error}</p>
      </div>
    );
  }

  const parsed = resume.parsed || {};

  return (
    <div className="page">
      <div className="page__eyebrow">Step 2 of 4</div>
      <h1 className="page__title">Candidate Profile</h1>
      <p className="page__subtitle">Here's what we extracted from your resume. Ready to start your interview?</p>

      <div className="page__panel">
        <div className="profile-row"><span>Name</span><span>{parsed.name || '—'}</span></div>
        <div className="profile-row"><span>Email</span><span>{parsed.email || '—'}</span></div>

        {parsed.skills?.length > 0 && (
          <div className="field" style={{ marginTop: 20 }}>
            <span className="field__label">Skills</span>
            <div className="skill-pill-row">
              {parsed.skills.map((s, i) => <span className="skill-pill" key={i}>{s}</span>)}
            </div>
          </div>
        )}

        {parsed.projects?.length > 0 && (
          <div className="field">
            <span className="field__label">Projects</span>
            <div className="project-list">
              {parsed.projects.map((p, i) => (
                <div className="project-item" key={i}>
                  <div className="project-item__name">{p.name}</div>
                  {p.description && <div className="project-item__desc">{p.description}</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        <button className="btn" style={{ marginTop: 24 }} onClick={() => navigate(`/setup/${resumeId}`)}>
          Start Interview
        </button>
      </div>
    </div>
  );
}
