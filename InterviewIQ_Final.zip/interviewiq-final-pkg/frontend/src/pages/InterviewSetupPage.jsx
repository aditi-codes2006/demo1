import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/client.js';
import { INTERVIEW_TYPES, DIFFICULTIES } from '../constants.js';
import './pages.css';

export default function InterviewSetupPage() {
  const { resumeId } = useParams();
  const navigate = useNavigate();
  const [interviewType, setInterviewType] = useState(INTERVIEW_TYPES[0]);
  const [difficulty, setDifficulty] = useState('Medium');
  const [status, setStatus] = useState('idle'); // idle | starting | error
  const [error, setError] = useState('');

  async function handleStart() {
    setStatus('starting');
    setError('');
    try {
      const result = await api.startInterview(resumeId, interviewType, difficulty);
      navigate(`/interview/${result.interviewId}`);
    } catch (err) {
      setError(err.message);
      setStatus('error');
    }
  }

  return (
    <div className="page">
      <div className="page__eyebrow">Step 3 of 4</div>
      <h1 className="page__title">Interview Setup</h1>
      <p className="page__subtitle">Choose the interview type and difficulty. You'll answer 6 adaptive questions grounded in your resume.</p>

      <div className="page__panel">
        <div className="field">
          <label className="field__label" htmlFor="interview-type">Interview Type</label>
          <select id="interview-type" className="field__select" value={interviewType} onChange={(e) => setInterviewType(e.target.value)}>
            {INTERVIEW_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div className="field">
          <label className="field__label" htmlFor="difficulty">Difficulty</label>
          <select id="difficulty" className="field__select" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
            {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <button className="btn" onClick={handleStart} disabled={status === 'starting'}>
          {status === 'starting' ? 'Starting…' : 'Start Interview'}
        </button>
        {status === 'error' && <p className="status-text status-text--error">{error}</p>}
      </div>
    </div>
  );
}
