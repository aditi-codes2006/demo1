import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import './pages.css';

export default function ResumeUploadPage() {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | uploading | error
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    if (!file) return;
    setStatus('uploading');
    setError('');
    try {
      const result = await api.uploadResume(file);
      navigate(`/profile/${result.resumeId}`);
    } catch (err) {
      setError(err.message);
      setStatus('error');
    }
  }

  return (
    <div className="page">
      <div className="page__eyebrow">Step 1 of 4</div>
      <h1 className="page__title">Upload your resume</h1>
      <p className="page__subtitle">PDF only. We'll extract your skills, projects, and experience to build your interview.</p>

      <form className="page__panel" onSubmit={handleSubmit}>
        <div className="field">
          <label className="field__label" htmlFor="resume-file">Resume (PDF)</label>
          <input
            id="resume-file"
            className="field__file"
            type="file"
            accept="application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
          />
        </div>
        <button className="btn" type="submit" disabled={!file || status === 'uploading'}>
          {status === 'uploading' ? 'Analyzing…' : 'Analyze Resume'}
        </button>
        {status === 'error' && <p className="status-text status-text--error">{error}</p>}
      </form>
    </div>
  );
}
