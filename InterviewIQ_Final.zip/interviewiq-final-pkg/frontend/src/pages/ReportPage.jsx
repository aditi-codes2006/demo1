import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/client.js';
import EvaluationDashboard from '../components/EvaluationDashboard.jsx';
import '../components/EvaluationDashboard.css';
import './pages.css';

export default function ReportPage() {
  const { interviewId } = useParams();
  const navigate = useNavigate();

  const [interview, setInterview] = useState(null);
  const [report, setReport] = useState(null);
  const [status, setStatus] = useState('loading'); // loading | error | not_ready | ready
  const [error, setError] = useState('');
  const [practiceAgainState, setPracticeAgainState] = useState('idle');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setStatus('loading');
      setError('');
      try {
        const iv = await api.getInterview(interviewId);
        if (cancelled) return;
        setInterview(iv);

        if (iv.finalReport) {
          setReport(iv.finalReport);
          setStatus('ready');
          return;
        }
        if (iv.status !== 'completed') {
          setStatus('not_ready');
          return;
        }
        const finished = await api.finishInterview(interviewId);
        if (cancelled) return;
        setReport(finished);
        setStatus('ready');
      } catch (err) {
        if (!cancelled) {
          setError(err.message);
          setStatus('error');
        }
      }
    })();
    return () => { cancelled = true; };
  }, [interviewId]);

  async function handlePracticeAgain() {
    if (!interview) return;
    setPracticeAgainState('loading');
    try {
      const result = await api.startInterview(interview.resumeId, interview.interviewType, interview.difficulty);
      navigate(`/interview/${result.interviewId}`);
    } catch (err) {
      setPracticeAgainState('error');
      setError(err.message);
    }
  }

  if (status === 'loading') {
    return <div className="page"><p className="status-text">Generating your evaluation report…</p></div>;
  }

  if (status === 'error') {
    return <div className="page"><p className="status-text status-text--error">{error}</p></div>;
  }

  if (status === 'not_ready') {
    return (
      <div className="page">
        <p className="status-text">
          This interview isn't finished yet — {interview?.answers?.length || 0} of {interview?.questions?.length || 6} questions answered.
        </p>
      </div>
    );
  }

  return (
    <>
      <EvaluationDashboard
        report={report}
        interview={interview}
        onPracticeAgain={handlePracticeAgain}
        practiceAgainState={practiceAgainState}
      />
      {practiceAgainState === 'error' && (
        <p className="status-text status-text--error" style={{ textAlign: 'center' }}>{error}</p>
      )}
    </>
  );
}
