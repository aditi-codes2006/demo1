import { Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './pages/LandingPage.jsx';
import ResumeUploadPage from './pages/ResumeUploadPage.jsx';
import CandidateProfilePage from './pages/CandidateProfilePage.jsx';
import InterviewSetupPage from './pages/InterviewSetupPage.jsx';
import InterviewRoomPage from './pages/InterviewRoomPage.jsx';
import ReportPage from './pages/ReportPage.jsx';
import DebugLookupPage from './pages/DebugLookupPage.jsx';
import './App.css';

export default function App() {
  return (
    <div className="app-shell">
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/upload" element={<ResumeUploadPage />} />
        <Route path="/profile/:resumeId" element={<CandidateProfilePage />} />
        <Route path="/setup/:resumeId" element={<InterviewSetupPage />} />
        <Route path="/interview/:interviewId" element={<InterviewRoomPage />} />
        <Route path="/report/:interviewId" element={<ReportPage />} />
        <Route path="/lookup" element={<DebugLookupPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}
