import ScoreRing from './ScoreRing.jsx';
import CategoryBar from './CategoryBar.jsx';

export default function EvaluationDashboard({ report, interview, onPracticeAgain, practiceAgainState }) {
  return (
    <div className="dashboard">
      <header className="dashboard__header">
        <div className="dashboard__meta">
          <span className="tag">{interview.interviewType}</span>
          <span className="tag">{interview.difficulty}</span>
          <span className="dashboard__meta-sep">·</span>
          <span className="dashboard__meta-text">{interview.questions?.length || 6} questions answered</span>
        </div>
        <h1 className="dashboard__title">Final Evaluation</h1>
      </header>

      <section className="panel panel--hero">
        <ScoreRing score={report.overallScore} />
        <div className="panel--hero__categories">
          {Object.entries(report.categoryScores).map(([key, score]) => (
            <CategoryBar key={key} categoryKey={key} score={score} />
          ))}
        </div>
      </section>

      <div className="dashboard__grid">
        <section className="panel">
          <h2 className="panel__title">Strengths</h2>
          <ul className="list list--positive">
            {report.strengths.map((s, i) => <li key={i}>{s}</li>)}
          </ul>
        </section>

        <section className="panel">
          <h2 className="panel__title">Weaknesses</h2>
          <ul className="list list--negative">
            {report.weaknesses.map((w, i) => <li key={i}>{w}</li>)}
          </ul>
        </section>
      </div>

      <section className="panel">
        <h2 className="panel__title">Knowledge Gaps</h2>
        {report.knowledgeGaps.length === 0 ? (
          <p className="panel__empty">No significant knowledge gaps detected.</p>
        ) : (
          <ul className="list list--gaps">
            {report.knowledgeGaps.map((g, i) => <li key={i}>{g}</li>)}
          </ul>
        )}
      </section>

      <section className="panel">
        <h2 className="panel__title">Project Assessment</h2>
        <div className="project-grid">
          {report.projectAssessment.map((p, i) => (
            <div className="project-card" key={i}>
              <div className="project-card__row">
                <span className="project-card__name">{p.project}</span>
                <span className="project-card__score">{p.understandingScore.toFixed(1)}/10</span>
              </div>
              <p className="project-card__assessment">{p.assessment}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="panel">
        <h2 className="panel__title">Question-by-Question Analysis</h2>
        <div className="qa-list">
          {report.questionAnalysis.map((q) => (
            <div className="qa-row" key={q.questionNumber}>
              <div className="qa-row__num">Q{q.questionNumber}</div>
              <div className="qa-row__body">
                <div className="qa-row__topic">{q.topic}</div>
                <div className="qa-row__assessment">{q.assessment}</div>
              </div>
              <div className="qa-row__score">{q.score != null ? q.score.toFixed(1) : '—'}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="panel">
        <h2 className="panel__title">Recommendations</h2>
        <div className="rec-list">
          {report.recommendations.map((r, i) => (
            <div className="rec-card" key={i}>
              <div className="rec-card__topic">{r.topic}</div>
              <div className="rec-card__reason">{r.reason}</div>
              <div className="rec-card__action">→ {r.action}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="panel">
        <h2 className="panel__title">Summary</h2>
        <p className="dashboard__summary">{report.interviewSummary}</p>
      </section>

      <div className="dashboard__cta">
        <button className="btn-primary" onClick={onPracticeAgain} disabled={practiceAgainState === 'loading'}>
          {practiceAgainState === 'loading' ? 'Starting new interview…' : 'Practice Again'}
        </button>
      </div>
    </div>
  );
}
