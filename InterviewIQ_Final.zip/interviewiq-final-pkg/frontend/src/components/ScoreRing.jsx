export default function ScoreRing({ score }) {
  const pct = Math.max(0, Math.min(1, score / 10));
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - pct);
  const color = score >= 7 ? 'var(--positive)' : score >= 5 ? 'var(--accent)' : 'var(--negative)';

  return (
    <div className="score-ring">
      <div className="score-ring__label">$ score --overall</div>
      <svg width="140" height="140" viewBox="0 0 140 140">
        <circle cx="70" cy="70" r={radius} fill="none" stroke="var(--neutral-bar)" strokeWidth="10" />
        <circle
          cx="70"
          cy="70"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform="rotate(-90 70 70)"
        />
        <text x="70" y="66" textAnchor="middle" className="score-ring__value">
          {score.toFixed(1)}
        </text>
        <text x="70" y="86" textAnchor="middle" className="score-ring__max">/ 10</text>
      </svg>
    </div>
  );
}
