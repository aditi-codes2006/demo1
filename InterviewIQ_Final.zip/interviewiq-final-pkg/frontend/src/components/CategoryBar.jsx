const LABELS = {
  technicalKnowledge: 'Technical Knowledge',
  projectUnderstanding: 'Project Understanding',
  problemSolving: 'Problem Solving',
  communication: 'Communication',
  confidence: 'Confidence',
};

export default function CategoryBar({ categoryKey, score }) {
  const pct = Math.max(0, Math.min(100, (score / 10) * 100));
  const color = score >= 7 ? 'var(--positive)' : score >= 5 ? 'var(--accent)' : 'var(--negative)';

  return (
    <div className="category-bar">
      <div className="category-bar__row">
        <span className="category-bar__label">{LABELS[categoryKey] || categoryKey}</span>
        <span className="category-bar__score" style={{ color }}>{score.toFixed(1)}</span>
      </div>
      <div className="category-bar__track">
        <div className="category-bar__fill" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}
