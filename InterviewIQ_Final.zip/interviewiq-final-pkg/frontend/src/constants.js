export const INTERVIEW_TYPES = ['Technical', 'HR', 'AIML', 'FullStack', 'ProjectDeepDive', 'Mixed'];
export const DIFFICULTIES = ['Easy', 'Medium', 'Hard'];
